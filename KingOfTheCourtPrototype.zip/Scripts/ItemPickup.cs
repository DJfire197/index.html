using UnityEngine;

public enum PickupType { Coin, Potion, Sword }

public class ItemPickup : MonoBehaviour
{
    public PickupType type;
    public int amount = 1;

    void OnTriggerEnter(Collider other)
    {
        var player = other.GetComponent<PlayerController>();
        if (player == null) return;

        if (type == PickupType.Coin) { AuthManager.Instance.AddCoins(amount); }
        else if (type == PickupType.Potion) { player.curHP = Mathf.Min(player.maxHP, player.curHP + amount); }
        else if (type == PickupType.Sword) { player.attackDamage += amount; }

        Destroy(gameObject);
    }
}