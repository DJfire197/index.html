using UnityEngine;

public class Chest : MonoBehaviour
{
    public GameObject coinPrefab, potionPrefab, swordPrefab;
    public void Open()
    {
        int choice = Random.Range(0, 3);
        GameObject prefab = (choice == 0) ? coinPrefab : (choice == 1) ? potionPrefab : swordPrefab;
        if (prefab != null) Instantiate(prefab, transform.position + Vector3.up*0.5f, Quaternion.identity);
        Destroy(gameObject);
    }

    void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            Open();
        }
    }
}