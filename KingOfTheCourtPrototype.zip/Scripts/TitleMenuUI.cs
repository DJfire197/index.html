using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class TitleMenuUI : MonoBehaviour
{
    [Header("Sign Up")]
    public InputField signupUser, signupPw;
    public Button signupBtn;

    [Header("Login")]
    public InputField loginUser, loginPw;
    public Button loginBtn;

    [Header("Main Buttons")]
    public Button playButton, skinsButton;

    void Start()
    {
        playButton.interactable = false;
        loginUser.text = PlayerPrefs.GetString("lastUser", "");
        signupBtn.onClick.AddListener(OnSignUpClicked);
        loginBtn.onClick.AddListener(OnLoginClicked);
        playButton.onClick.AddListener(()=> SceneManager.LoadScene("IslandScene"));
        skinsButton.onClick.AddListener(()=> SceneManager.LoadScene("CharacterScene"));
    }

    void OnSignUpClicked()
    {
        bool ok = AuthManager.Instance.SignUp(signupUser.text, signupPw.text);
        if (ok) { playButton.interactable = true; SceneManager.LoadScene("CharacterScene"); }
        else Debug.Log("Sign Up failed (maybe user exists or blank fields).");
    }

    void OnLoginClicked()
    {
        bool ok = AuthManager.Instance.Login(loginUser.text, loginPw.text);
        if (ok) { playButton.interactable = true; SceneManager.LoadScene("CharacterScene"); }
        else Debug.Log("Login failed (wrong user or pw).");
    }
}