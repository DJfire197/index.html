using UnityEngine;

public class AuthManager : MonoBehaviour
{
    public static AuthManager Instance;
    public string Username { get; private set; }

    void Awake()
    {
        if (Instance == null) { Instance = this; DontDestroyOnLoad(gameObject); }
        else Destroy(gameObject);
    }

    public bool SignUp(string username, string password)
    {
        username = username.Trim();
        if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password)) return false;
        if (PlayerPrefs.HasKey(username + "_pw")) return false;
        PlayerPrefs.SetString(username + "_pw", password);
        PlayerPrefs.SetString("lastUser", username);
        PlayerPrefs.SetInt(username + "_coins", 0);
        PlayerPrefs.SetString(username + "_skin", "poor_boy");
        PlayerPrefs.SetInt(username + "_rank", 1);
        PlayerPrefs.SetInt(username + "_xp", 0);
        PlayerPrefs.Save();
        Username = username;
        return true;
    }

    public bool Login(string username, string password)
    {
        username = username.Trim();
        if (!PlayerPrefs.HasKey(username + "_pw")) return false;
        if (PlayerPrefs.GetString(username + "_pw") != password) return false;
        Username = username;
        PlayerPrefs.SetString("lastUser", username);
        return true;
    }

    public int GetCoins() => string.IsNullOrEmpty(Username) ? 0 : PlayerPrefs.GetInt(Username + "_coins", 0);
    public void AddCoins(int amount) { if (string.IsNullOrEmpty(Username)) return; PlayerPrefs.SetInt(Username + "_coins", GetCoins() + amount); PlayerPrefs.Save(); }
    public void SetSkin(string id) { if (string.IsNullOrEmpty(Username)) return; PlayerPrefs.SetString(Username + "_skin", id); PlayerPrefs.Save(); }
    public string GetSkin() { if (string.IsNullOrEmpty(Username)) return PlayerPrefs.GetString("lastUser" + "_skin", "poor_boy"); return PlayerPrefs.GetString(Username + "_skin", "poor_boy"); }
    public int GetRank() { if (string.IsNullOrEmpty(Username)) return 1; return PlayerPrefs.GetInt(Username + "_rank", 1); }
    public void AddXP(int xp)
    {
        if (string.IsNullOrEmpty(Username)) return;
        int cur = PlayerPrefs.GetInt(Username + "_xp", 0) + xp; PlayerPrefs.SetInt(Username + "_xp", cur);
        if (cur >= 700) PlayerPrefs.SetInt(Username + "_rank", 4);
        else if (cur >= 300) PlayerPrefs.SetInt(Username + "_rank", 3);
        else if (cur >= 100) PlayerPrefs.SetInt(Username + "_rank", 2);
        PlayerPrefs.Save();
    }
}