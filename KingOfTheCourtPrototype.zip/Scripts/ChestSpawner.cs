using UnityEngine;

public class ChestSpawner : MonoBehaviour
{
    public Transform[] spawnPoints;
    public GameObject chestPrefab;
    public float initialSpawnDelay = 1f;
    public float spawnInterval = 20f;

    void Start()
    {
        Invoke(nameof(SpawnAll), initialSpawnDelay);
        InvokeRepeating(nameof(SpawnRandom), spawnInterval, spawnInterval);
    }

    void SpawnAll()
    {
        foreach (var s in spawnPoints) SpawnAt(s.position);
    }

    void SpawnRandom()
    {
        if (spawnPoints.Length == 0) return;
        var p = spawnPoints[Random.Range(0, spawnPoints.Length)];
        SpawnAt(p.position);
    }

    void SpawnAt(Vector3 pos)
    {
        Instantiate(chestPrefab, pos, Quaternion.identity);
    }
}